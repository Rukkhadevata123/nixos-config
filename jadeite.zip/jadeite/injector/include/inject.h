#pragma once

#include <windows.h>

void inject(HANDLE process, const void *payload, size_t payloadSize, const wchar_t *dllPath);
