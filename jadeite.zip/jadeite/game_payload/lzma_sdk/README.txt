LZMA decoder from the LZMA SDK 24.07

LZMA SDK: https://7-zip.org/sdk.html
Author: Igor Pavlov
