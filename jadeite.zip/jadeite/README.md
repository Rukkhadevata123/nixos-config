# Jadeite Autopatcher
### Current game support:
- **3rd**: glb/sea/tw/kr/jp **v7.8.0+**, cn **v7.8.0+**
- **SR**: os/cn **v2.5.0+**

You can expect newer versions to work immediately after release with the same jadeite binary if the version is specified with a + above

**Note**: the Steam version of 3rd was reported to work, however I neither tested it nor intend to support it, so it might break at any time. Use at your own risk

**Highly experimental Waves project:** https://codeberg.org/TeamHarmony/harmonic

## Information
The anticheat the games use is fundamentally incompatible with Wine in multiple ways. This tool launches the game without it (`injector`) and imitates it's behaviour (`game_payload`)

**Using third-party software (such as this tool) with the games violates their Terms of Service**. Therefore, **you may receive a ban**. No bans were ever reported with jadeite, however the legacy patch for pre-v1.1.0 SR (not present in this repository) did cause many. **Use at your own risk and only if you understand all the possible consequences**

**This is not a cheating tool**. Using it with Windows is not possible, and Windows support is not planned or intended in any way. However, as it does not perform any on-disk file modifications, you may reuse the same game install for Windows if you have a dual-boot setup

**Refer to [third-party launchers](#third-party-launchers)** for convenient usage. If you don't want to (or can't) use third-party launchers, **make sure to read the [requirements section](#requirements) and continue to the [usage section](#usage)**

## Requirements
Despite only being strictily required by SR, **Wine 9.5+ is recommended for all games**

**[DXVK](https://github.com/doitsujin/dxvk) is strongly recommended in most cases**, but not required. See game-specific notes

**GStreamer with proper plugins for h.264-encoded video playback is required**:
- **At least the following should be installed**: `gst-pulgins-base`, `gst-plugins-good`, `gst-plugins-bad`, `gst-libav` (with `avdec_h264`)
- **It is important to not use** `openh264`, as it causes major issues with video playback, such as stuttering, video artifacts and hangs. `avdec_h264` has a higher rank value, so it will be used instead of the broken decoder automatically if present
- Sometimes, `avdec_h264` is missing from `gst-libav` due to FFmpeg libraries being compiled without h.264 support. In this case, in-game videos will not work correctly. Notably, it's not available by default in Flatpak runtimes: the application maintainer has to compile the FFmpeg libraries with h.264 support manually
- Proton and derivatives (including Wine-GE-Proton) typically include their own GStreamer plugins and use them instead of the system-installed ones, which might either help or cause issues

### Game-specific notes

**3rd-specific**: 
- On some systems, WineD3D (builtin Wine graphics translation layer) might show better performance than DXVK. However, this is largely untested, so you might run into random issues

**SR-specific**:
- **Wine 9.5+ (vanilla or a non-Proton derivative) is required to play h.264-encoded cutscenes** that were introduced in SR v2.1.0. You may experience black screens, video artifacts or hangs on lower Wine versions and any Proton versions. **As Proton and Proton derivatives currently can't play the cutscenes, GStreamer together with all plugins listed above is required**
- WineD3D does not support the way SR uses transform feedback for model skinning. As a result, all character models will render incorrectly, making the game unplayable without DXVK. You can prevent this by passing `-disable-gpu-skinning` to the game (see command line interface reference below). However, it is better to install DXVK, as WineD3D performance is usually a lot worse

## Usage
Manual usage instructions:
- Download the game you want to run
- Download the latest release from this repository
- Extract the archive (**NOT INTO THE GAME DIRECTORY! THIS IS IMPORTANT!**)
- Run `wine jadeite.exe 'Z:\wine\path\to\game.exe'`

`./block_analytics.sh` from the archive can be used to block the games from accessing analytics servers (`chmod +x block_analytics.sh` might be necessary first). This requires superuser privileges

Detailed command line interface reference: `jadeite.exe [game path] <launcher path> <game args...>`, where:
- `game path` - Wine path to the game (required)
- `launcher path` - Wine path to the launcher process (optional, default is `C:\Windows\explorer.exe`). The launcher process will be used to start the game. You can specify the path to the official launcher here. Specifying anything other than `explorer.exe` or the official launcher is not recommended. Specify `--` to skip this argument and use the default
- `game args...` - arguments to pass to the game process (optional)

Example command: `jadeite.exe 'Z:\path\to\game.exe' -- -screen-fullscreen 1`

## Configuration
These environment variables can be used to configure the behaviour of the tool. Any value except empty string counts as set. `1` will be used in all examples

**Global**:
- `WAIT_BEFORE_RESUME=1` - show a messagebox and wait for user input before resuming the game process. Useful on my side for debugging

## Internals and building
To compile jadeite, you will need meson, mingw and nasm. You can probably install all three using your repository's package manager. Once all dependencies are installed, run `./build.sh` in this directory. The compiled files will be located in `./out`

A part of the source code is witheld (`game_payload/src/core.c`). This is a forced measure to make abuse more difficult. However, a precompiled blob is provided in the repo. `build.sh` will use it automatically

All source code except `core.c` is available in this repository. You can take a look around

## Guildelines
1. **Please don't share this project in public.** This might attract unnecessary attention from either the Game Company or the Anticheat Company
2. **Please don't abuse this project for cheating.** We're just trying to play the games through Wine

## Troubleshooting
Please do not report any issues with the Game to the official channels. Use the issue tracker of this repository

## Third-party launchers
- **Honkers Launcher** &mdash; Linux launcher for 3rd ([GitHub](https://github.com/an-anime-team/honkers-launcher) | [Codeberg](https://codeberg.org/an-anime-team/honkers-launcher))
- **The Honkers Railway Launcher** &mdash; Linux launcher for SR ([GitHub](https://github.com/an-anime-team/the-honkers-railway-launcher) | [Codeberg](https://codeberg.org/an-anime-team/the-honkers-railway-launcher))

## Credits
- **mkrsym1** &mdash; project leader, reverse engineering
- **[EternalStudentDesuKa](https://github.com/EternalStudentDesuKa)** &mdash; major help with analyzing network activity
- **[An Anime Team](https://github.com/an-anime-team)** &mdash; Honkers Launcher and The Honkers Railway Launcher
- Some others (credited in the source code)

License: MIT
