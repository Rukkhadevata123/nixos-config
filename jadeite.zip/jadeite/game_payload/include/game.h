#pragma once

#include <windows.h>

struct game_data {
    int is_mb;
    const char *base_module_name;
    const char *assembly_name;
    const char *txs_section_name;
    const char *tvm_section_name;
};

void game_detect(struct game_data *buf);

void hi3_fill_data(struct game_data *buf);
void hsr_fill_data(struct game_data *buf);
