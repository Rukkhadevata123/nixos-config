### 1.0.0
- First version

### 1.1.0
- HSR support

### 1.1.9
- Fixed a bug which could cause the game to crash in odd scenarios

### 1.1.10
- Fixed a subtle bug introduced in 1.1.9

### 1.1.11
- Fixed an additional issue introduced in 1.1.9

### 2.0.0
- Almost a full rewrite, functionality unchanged
- Added support for HI3 sea/cn/tw/jp/kr

### 3.0.0
- Integrated table extractor

### 3.0.1
- Fixed a bug that caused HI3 to crash

### 3.0.2
- Fixed multiple error messageboxes showing invalid characters
- Added handling for more error conditions 

### 3.0.4
- Moved LoadLibrary call into core from main
