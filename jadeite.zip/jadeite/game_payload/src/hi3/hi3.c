#include <utils.h>
#include <msg.h>
#include <pe.h>
#include <main.h>

#include <game.h>

const char *HI3_BASE_MODULE_NAME = "BH3Base.dll";
const char *HI3_ASSEMBLY_NAME    = "UserAssembly.dll";
const char *HI3_TXS_SECTION_NAME = ".ace";
const char *HI3_TVM_SECTION_NAME = ".tvm0";


void hi3_fill_data(struct game_data *buf) {
    buf->is_mb = 1;
    buf->base_module_name = HI3_BASE_MODULE_NAME;
    buf->assembly_name = HI3_ASSEMBLY_NAME;
    buf->txs_section_name = HI3_TXS_SECTION_NAME;
    buf->tvm_section_name = HI3_TVM_SECTION_NAME;
}
