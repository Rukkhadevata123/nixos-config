#pragma once

#include <windows.h>

#include <game.h>

void ace_fake_driver_files();

HMODULE ace_load_base_module(struct game_data *game);
HMODULE ace_load_driver_module();

void *ace_unpack_shell_data(struct game_data *game, HMODULE baseModule, size_t *outSize);
