#include <utils.h>
#include <msg.h>
#include <main.h>

#include <game.h>

void hsr_fill_data(struct game_data *buf) {
    if (!utils_env_enabled("DISABLE_WINTRUST_PATCH")) {
        // stub some functions in wintrust to prevent the game from complaining
        const char STUB[] = {
            0xB8, 0x01, 0x00, 0x00, 0x00,   // mov eax, 1
            0xC3                            // ret
        };

        const char *STUB_FUNCTIONS[] = {
            "CryptCATAdminEnumCatalogFromHash",
            "CryptCATCatalogInfoFromContext",
            "CryptCATAdminReleaseCatalogContext"
        };

        HMODULE wintrust = LoadLibraryA("wintrust.dll");

        for (size_t i = 0; i < UTILS_COUNT(STUB_FUNCTIONS); i++) {
            void *fn = GetProcAddress(wintrust, STUB_FUNCTIONS[i]);
            utils_write_protected_memory(fn, STUB, sizeof(STUB));
        }
    } else {
        msg_warn_a("Disabled wintrust.dll patch. The game will likely not work");
    }

    buf->is_mb = 0;
}
