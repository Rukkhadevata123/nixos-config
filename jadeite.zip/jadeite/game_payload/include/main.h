#pragma once

#define ISSUE_SUFFIX "Please open an issue on the jadeite repository specifying your game edition/region and version"

void unload_ctr_inc();
void unload_ctr_dec();
