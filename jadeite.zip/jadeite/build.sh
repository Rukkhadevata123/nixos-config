#!/usr/bin/env bash
set -e

strip="x86_64-w64-mingw32-strip"

rm -f jadeite.zip
rm -rf out

sh setup.sh --buildtype=release
meson compile -C build

mkdir out

cp ./build/injector/jadeite.exe ./out
cp ./build/injector/launcher_payload.dll ./out
cp ./build/game_payload/game_payload.dll ./out
cp ./block_analytics.sh ./out
cp ./LICENSE.txt ./out

$strip ./out/*.{exe,dll}

if [ "x$1" = "xrelease" ]; then
    cd out
    zip ../jadeite.zip *
fi
