#include <ntdll.h>
#include <pe.h>
#include <msg.h>
#include <utils.h>
#include <tlzma.h>
#include <main.h>

#include <ace.h>

static void _dll_notification(ULONG reason, const PLDR_DLL_NOTIFICATION_DATA data, void *context) {
    if (reason != 1) { // 1 - attach
        return;
    }

    // context should be set to the target module name
    wchar_t *targetModuleName = (wchar_t*)context;

    if (wcsicmp(targetModuleName, data->Loaded.BaseDllName->Buffer) != 0) {
        return;
    }

    IMAGE_DOS_HEADER *dosHeader = (IMAGE_DOS_HEADER*)data->Loaded.DllBase;
    IMAGE_NT_HEADERS64 *ntHeaders = (IMAGE_NT_HEADERS64*)(((char*)data->Loaded.DllBase) + dosHeader->e_lfanew);

    // Replace entry point with a stub
    void *entryPoint = ((char*)data->Loaded.DllBase) + ntHeaders->OptionalHeader.AddressOfEntryPoint;

    const char ENTRY_POINT_STUB[] = {
        0xB8, 0x01, 0x00, 0x00, 0x00,   // mov eax, 1
        0xC3                            // ret
    };
    utils_write_protected_memory(entryPoint, ENTRY_POINT_STUB, sizeof(ENTRY_POINT_STUB));

    // Break the TLS struct
    IMAGE_DATA_DIRECTORY *tlsDirectory = &ntHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS];
    
    IMAGE_DATA_DIRECTORY zero = { 0 };
    utils_write_protected_memory(tlsDirectory, &zero, sizeof(zero));
}

static void _create_driver_file(const char *path) {
    // They only report presence
    HANDLE file = CreateFileA(path, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

    if (file == INVALID_HANDLE_VALUE) {
        msg_err_a("Could not create driver file: %s", path);
    }

    CloseHandle(file);
}

void ace_fake_driver_files() {
    _create_driver_file("ACE-BASE.sys");

    // Just in case
    _create_driver_file("C:\\windows\\system32\\drivers\\ACE-BASE.sys");
}

static HMODULE _load_module_patched(wchar_t *path) {
    // Get filename from the path
    wchar_t *name = wcsrchr(path, '\\');
    name = name ? name + 1 : path;

    void *cookie;
    LdrRegisterDllNotification(0, &_dll_notification, name, &cookie);

    HMODULE module = LoadLibraryW(path);
    if (!module) {
        msg_err_w(L"Could not load module: %ls", path);
    }

    // LoadLibraryW is synchronous; the notification function has already finished executing
    LdrUnregisterDllNotification(cookie);

    return module;
}

HMODULE ace_load_base_module(struct game_data *game) {
    wchar_t baseModuleName[MAX_PATH];
    MultiByteToWideChar(CP_UTF8, 0, game->base_module_name, strlen(game->base_module_name) + 1, baseModuleName, MAX_PATH);

    return _load_module_patched(baseModuleName);
}

HMODULE ace_load_driver_module() {
    return _load_module_patched(L"AntiCheatExpert\\InGame\\x64\\ACE-DRV64.dll");
}

void *ace_unpack_shell_data(struct game_data *game, HMODULE baseModule, size_t *outSize) {
    IMAGE_SECTION_HEADER *section = pe_find_section(baseModule, game->txs_section_name);
    if (!section) {
        msg_err_a("Failed to find the shell data section in the base module. " ISSUE_SUFFIX);
    }

    void *data = ((uint8_t*)baseModule) + section->VirtualAddress;
    return tlzma_decode(data, outSize, NULL);
}
