#include <windows.h>

#include <ace.h>
#include <game.h>
#include <core.h>
#include <utils.h>
#include <msg.h>

#define NTDLL_DYNAMIC_LINK_IMPL
#include <ntdll.h>

#include <main.h>

HMODULE this_module;
size_t unload_ctr = 0;

void unload_ctr_inc() {
    unload_ctr++;
}

void unload_ctr_dec() {
    unload_ctr--;
    if (unload_ctr == 0) {
        void *pFreeLibrary = GetProcAddress(GetModuleHandleA("kernel32.dll"), "FreeLibrary");
        CreateThread(NULL, 0, pFreeLibrary, this_module, 0, NULL);
    }
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    // Only listen to attach
    if (reason != DLL_PROCESS_ATTACH) {
        return TRUE;
    }

    this_module = instance;

    // Dynamically link functions from ntdll
    _ntdll_link();

    // Detect which game the user is trying to run
    struct game_data game;
    game_detect(&game);

    if (game.is_mb) {
        // Create fake ACE driver files
        ace_fake_driver_files();

        // Load both ACE modules
        HMODULE baseModule = ace_load_base_module(&game);
        ace_load_driver_module();

        // Unpack shell data
        size_t shellDataSize;
        void *shellData = ace_unpack_shell_data(&game, baseModule, &shellDataSize);

        // ...magic
        core_setup_patcher(&game, shellData, shellDataSize);
    }

    // Load the UnityPlayer module
    LoadLibraryA("UnityPlayer.dll");

    return TRUE;
}
