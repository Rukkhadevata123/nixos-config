#!/usr/bin/env sh

cp "$1" "$2"
cp "$1" "$3"
