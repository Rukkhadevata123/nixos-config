#include <msg.h>
#include <utils.h>

#include <game.h>

typedef void (*fill_fn)(struct game_data *buf);

struct name_fn_pair {
    const wchar_t *name;
    fill_fn fill;
};

const struct name_fn_pair GAMES[] = {
    { L"BH3",      &hi3_fill_data },
    { L"StarRail", &hsr_fill_data }
};

void game_detect(struct game_data *buf) {
    wchar_t exePath[MAX_PATH];
    GetModuleFileNameW(NULL, exePath, MAX_PATH);

    // Leave only the basename
    wchar_t *exeName = wcsrchr(exePath, L'\\') + 1;

    // Cut off extension (.exe)
    wchar_t *extensionDot = wcsrchr(exeName, L'.');
    if (extensionDot != NULL) {
        *extensionDot = L'\0';
    }

    for (size_t i = 0; i < UTILS_COUNT(GAMES); i++) {
        if (wcsicmp(exeName, GAMES[i].name) == 0) {
            GAMES[i].fill(buf);
            return;
        }
    }

    if (!utils_env_enabled("JADEITE_ALLOW_UNKNOWN")) {
        msg_err_w(L"Unknown game: \"%ls\"\n\nSet JADEITE_ALLOW_UNKNOWN=1 to continue anyway (it will likely not work)", exeName);
    }

    buf->is_mb = 0;
}
