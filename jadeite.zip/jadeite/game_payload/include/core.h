#pragma once

#include <game.h>

void core_setup_patcher(struct game_data *game, void *shellData, size_t shellDataLen);
